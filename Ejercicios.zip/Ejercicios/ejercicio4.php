<html>
<head>
 <title>Ejercicios 4</title>
 <meta charset="utf-8"/>
 <link rel="Stylesheet" type="text/css" href="css/style.css"/>
</head>
 <body>
 <h1>PROGRAMACION DE APLICACIONES WEB</h1>
<h4>Mostrar en pantalla cual es el mayor de dos numeros</h4> 
 
 <form action="procesar1.php" method="post" name="Mayordenumeros">
  Valor 1:<br>
  <input type="text" name="N1" value="" placeholder="Introduce el primer Valor">
  <br>
  Valor 2:<br>
  <input type="text" name="N2" value="" placeholder="Introduce el segundo Valor">
  
  <br><br>
<input type="submit" value="Calcular">
</form>

</body>
</html>

 <p>Raquel Alejandra Martinez Ramirez</p>
 <a href="index.php">Regresar al Menu</a>
 </body>
 </html>
