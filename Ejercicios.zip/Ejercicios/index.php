<html lang="es">
  
<head>
 <title>Ejercicios en PHP</title>
 <meta charset="utf-8"/>

 <link rel="Stylesheet" type="text/css" href="css/style.css"/>
</head>
 <body >
   
<center> <h1>Menú</h1></center>
 
  <div id="menu">
     
    
   <a href="ejercicio1.php">Ejercicio 1</a>
   <a href="ejercicio2.php">Ejercicio 2</a>
   <a href="ejercicio3.php">Ejercicio 3</a>
   <a href="ejercicio4.php">Ejercicio 4</a>
   <a href="ejercicio5.php">Ejercicio 5</a>
  
    </div>
</body>


</html>
