<html>
<head>
 <title>Ejercicios 5</title>
 <meta charset="utf-8"/>
 <link rel="Stylesheet" type="text/css" href="css/style.css"/>
</head>
 <body>
 <h1>PROGRAMACION DE APLICACIONES WEB</h1>
<h4>Mostrar en pantalla cual es el mayor de tres numeros</h4> 
 <?php
 $n1=$_POST['N1'];
  $n2=$_POST['N2'];
  $n3=$_POST['N3'];
 if (($n1 > $n2) else ($n2 < $n3)) {
    echo 'n1 es la mayor';
} elseif (($n2 > $n1) else ($n2 < $n3)) {
    echo 'n2 es la mayor';
} elseif (($n3 > $n1) else ($n3 < $n2)) {
    echo 'n3 es la mayor';
}
echo 'la mayor es: '.$mayor. '<br/>';

echo '<br /><br />';
 
 ?>
 <p>Raquel Alejandra Martinez Ramirez</p>
 <a href="index.php">Regresar al Menu</a>
 </body>
 </html>


