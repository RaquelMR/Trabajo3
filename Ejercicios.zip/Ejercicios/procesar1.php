<html>
<head>
 <title>Ejercicios 4</title>
 <meta charset="utf-8"/>
 <link rel="Stylesheet" type="text/css" href="css/style.css"/>
</head>
 <body>
 <h1>PROGRAMACION DE APLICACIONES WEB</h1>
 <h4>Mostrar en pantalla cual es el mayor de dos numeros</h4> 
 
<?php

  $n1=$_POST['N1'];
  $n2=$_POST['N2'];


 if ($n1>$n2){
     echo "El primer numero (".$n1.") es mayor que el segundo (".$n2.")";
 }
 elseif ($n1==$n2) {
 echo "El primer numero (".$n1.") es igual al segundo (".$n2.")";  
 }
 else {
     echo "El primer numero (".$n1.") es menor que el segundo (",$n2.")";
 }
 ?>

 
<p>Raquel Alejandra Martinez Ramirez</p>
<a href="index.php">Regresar a menu</a>
</body>
</html>
