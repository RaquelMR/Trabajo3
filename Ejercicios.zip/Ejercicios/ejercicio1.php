<html>
<head>
 <title>Ejercicios 1</title>
 <meta charset="utf-8"/>
 <link rel="Stylesheet" type="text/css" href="css/style.css"/>
</head>
 <body>
 
 <h1>PROGRAMACION DE APLICACIONES WEB</h1>
 <h4> Hacer un programa que sume,reste,multiplique y divida dos variables<h4>
 <form action="procesar.php" method="post" name="calculadora">
  Valor 1:<br>
  <input type="text" name="Numero1" value="" placeholder="Introduce el primer Valor">
  <br>
  Valor 2:<br>
  <input type="text" name="Numero2" value="" placeholder="Introduce el segundo Valor">
  
  <br><br>
<input type="submit" value="Calcular">
</form>


 <a href="index.php">Regresar al menu</a>
 <p>Raquel Alejandra Martinez Ramirez</p>
</body>
</html>
