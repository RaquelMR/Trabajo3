<html>
<head>
 <title>Ejercicios 3</title>
 <meta charset="utf-8"/>
 <link rel="Stylesheet" type="text/css" href="css/style.css"/>
</head>
 <body>
 <h1>PROGRAMACION DE APLICACIONES WEB</h1>
<h4>Mostrar en pantalla una tabla de 1 por 10</h4> 
 <?php

 

  echo "<h2>BUCLE WHILE</h2><br>";
  echo "<table border=1>";
  for ($i=0;$i<10;$i++)
  {
      echo"<tr><td>". "Linea ".$i."<br>";
  }
 echo"</td></tr>";
 echo "</table>";
  ?>
  <p>Raquel Alejandra Martinez Ramirez</p>
  <a href="index.php">Regresar al Menu</a>
  </body>
  </html>
