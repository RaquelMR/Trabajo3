<html>
<head>
 <title>Ejercicios 1</title>
 <meta charset="utf-8"/>
 <link rel="Stylesheet" type="text/css" href="css/style.css"/>
</head>
 <body>
 <h1>PROGRAMACION DE APLICACIONES WEB</h1>
 <h4> Hacer un programa que sume,reste,multiplique y divida dos variables<h4>
 <?php

  $numero1=$_POST['Numero1'];
  $numero2=$_POST['Numero2'];


  $suma=$numero1+$numero2;
  echo "$numero1+$numero2"."<br>";
  echo "suma =".$suma. "<br>";
  
  $resta=$numero1-$numero2;
  echo "$numero1-$numero2"."<br>";
  echo "resta = ".$resta."<br>";
 
  $multiplicacion=$numero1*$numero2;
  echo "$numero1*$numero2"."<br>";
  echo "multiplicacion = ".$multiplicacion."<br>";

  $division=$numero1/$numero2;
  echo "$numero1/$numero2"."<br>";
  echo "division = ".$division."<br>";

?>




 
<p>Raquel Alejandra Martinez Ramirez</p>
<a href="index.php">Regresar a menu</a>
</body>
</html>
